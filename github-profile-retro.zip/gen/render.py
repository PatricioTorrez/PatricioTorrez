import sys, glob, os, asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(device_scale_factor=1)
        for f in sorted(glob.glob('/tmp/gh/profile/assets/*.svg')):
            await pg.goto('file://' + f)
            el = await pg.query_selector('svg')
            await el.screenshot(path='/tmp/gh/prev/' + os.path.basename(f)[:-4] + '.png', animations='disabled')
        await b.close()
asyncio.run(main())
