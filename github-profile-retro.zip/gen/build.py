import os, random
from pixfont import text, width
from voxel import Scene, M, P, character

OUT = os.path.join(os.path.dirname(__file__), '..', 'profile', 'assets')
os.makedirs(OUT, exist_ok=True)
random.seed(7)

CSS = """
<style>
.bob{animation:bob 2.4s steps(6) infinite}
.bob2{animation:bob 2.4s steps(6) -0.8s infinite}
.bob3{animation:bob 2.4s steps(6) -1.6s infinite}
.float{animation:fl 4s steps(8) infinite}
.blink{animation:bl 1s steps(1) infinite}
.tw{animation:tw 3s steps(1) infinite}
@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
@keyframes fl{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
@keyframes bl{50%{opacity:0}}
@keyframes tw{0%,100%{opacity:1}40%{opacity:.25}70%{opacity:.7}}
@media (prefers-reduced-motion:reduce){*{animation:none!important}}
</style>"""


def svg_doc(w, h, body, title):
    title = title.replace("&", "&amp;")
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" '
            f'shape-rendering="crispEdges" role="img" aria-label="{title}"><title>{title}</title>{CSS}{body}</svg>')


def frame(w, h, c1=P['dgrey'], c2=P['grey'], bg=P['bg']):
    """Pixel frame with stepped corners."""
    u = 4
    return (f'<rect x="{u}" y="0" width="{w-2*u}" height="{h}" fill="{c1}"/>'
            f'<rect x="0" y="{u}" width="{w}" height="{h-2*u}" fill="{c1}"/>'
            f'<rect x="{u*2}" y="{u}" width="{w-4*u}" height="{h-2*u}" fill="{c2}"/>'
            f'<rect x="{u}" y="{u*2}" width="{w-2*u}" height="{h-4*u}" fill="{c2}"/>'
            f'<rect x="{u*2}" y="{u*2}" width="{w-4*u}" height="{h-4*u}" fill="{bg}"/>')


def stars(w, h, n, avoid=None):
    out = []
    cols = [P['white'], P['cyan'], P['yellow'], P['lgrey']]
    for i in range(n):
        x, y = random.randint(14, w - 18), random.randint(14, h - 18)
        if avoid and avoid(x, y):
            continue
        sz = random.choice([2, 2, 3, 4])
        c = random.choice(cols)
        d = f'-{random.random()*3:.1f}s'
        if sz == 4:  # plus-shaped sparkle
            out.append(f'<g class="tw" style="animation-delay:{d}" fill="{c}"><rect x="{x}" y="{y-3}" width="2" height="8"/><rect x="{x-3}" y="{y}" width="8" height="2"/></g>')
        else:
            out.append(f'<rect class="tw" style="animation-delay:{d}" x="{x}" y="{y}" width="{sz}" height="{sz}" fill="{c}"/>')
    return "".join(out)


# ------------------------------------------------------------------ banner
def island():
    sc = Scene()
    W, D = 13, 10
    for x in range(W):
        for y in range(D):
            sc.put(x, y, 0, 'grass')
    layers = [(-1, 0, 'dirt'), (-2, 1, 'dirt'), (-3, 2, 'dirt2'), (-4, 3, 'dirt2'), (-5, 5, 'dirt2')]
    for z, ins, m in layers:
        for x in range(ins, W - ins):
            for y in range(ins, D - ins):
                sc.put(x, y, z, m)
    # stones in the dirt
    for p in [(12, 3, -1), (12, 6, -2), (5, 9, -1), (9, 8, -3)]:
        if p in sc.v: sc.put(*p, 'stone')
    # CRT TV (back-left), screen faces +y
    sc.box(0, 1, 1, 5, 3, 4, 'dark')
    for x in range(1, 4):
        for z in range(2, 4):
            sc.put(x, 3, z, 'dark', left=M['screen'][0])
    sc.put(1, 3, 3, 'dark', left=P['cyan']); sc.put(2, 3, 3, 'dark', left=P['sky'])
    sc.put(3, 3, 2, 'dark', left=M['screen'][0], blink=P['lime'])     # blinking cursor
    sc.put(4, 3, 3, 'dark', left=P['red']); sc.put(4, 3, 2, 'dark', left=P['lgrey'])  # knobs
    for p in [(1, 2, 5), (3, 2, 5), (0, 2, 6), (4, 2, 6)]:
        sc.put(*p, 'black')                                          # antenna
    # controller in front of the TV
    sc.box(1, 6, 1, 3, 1, 1, 'black'); sc.put(1, 6, 1, 'black', top=P['lgrey']); sc.put(3, 6, 1, 'black', top=P['red'])
    # retro console (front-middle)
    sc.box(5, 6, 1, 5, 3, 1, 'light')
    sc.box(5, 6, 2, 5, 1, 1, 'dark')
    sc.box(6, 6, 3, 3, 1, 2, 'red')                                  # cartridge
    sc.put(5, 8, 1, 'light', left=P['red'])                          # power led
    sc.put(6, 8, 1, 'light', left=P['dgrey']); sc.put(7, 8, 1, 'light', left=P['dgrey'])
    # tree (front-left)
    sc.box(1, 8, 1, 1, 1, 3, 'wood')
    sc.box(0, 7, 4, 3, 3, 2, 'leaf'); sc.put(1, 8, 6, 'leaf'); sc.put(2, 9, 5, 'grass')
    # bits
    sc.put(12, 9, 1, 'grass', top=P['yellow']); sc.put(12, 1, 1, 'grass', top=P['red']); sc.put(6, 1, 1, 'stone')
    character(sc, 8, 2, 1)
    return sc


def banner():
    w, h = 960, 360
    b = [frame(w, h)]
    # left text: avoid stars behind the copy
    b.append(stars(w, h, 70, avoid=lambda x, y: x < 540 and 50 < y < 320))
    b.append(text("1UP 002026", 36, 30, 2, P['red']))
    b.append(text("HI-SCORE 999999", w - 36 - width("HI-SCORE 999999", 2), 30, 2, P['lgrey']))
    b.append(text("HOLA, SOY / HI, I'M", 56, 78, 3, P['lgrey']))
    b.append(text("PATRICIO", 56, 108, 7, P['white'], shadow=P['purple']))
    b.append(text("TORREZ", 56, 170, 7, P['yellow'], shadow=P['red']))
    b.append(text("WEB & MOBILE DEVELOPER", 56, 238, 3, P['cyan']))
    b.append(text("DESARROLLADOR WEB & MÓVIL", 56, 264, 3, P['lgrey']))
    b.append(f'<g class="blink">{text("} PRESS START", 56, 306, 3, P['white'])}</g>')
    s, ox, oy = 14, 722, 128
    b.append(f'<g class="float">{island().svg(ox, oy, s)}</g>')
    coin = Scene(); coin.put(0, 0, 0, 'yellow')
    q = Scene(); q.put(0, 0, 0, 'red', left=P['orange'], right=P['red'], top=P['yellow'])
    gem = Scene(); gem.put(0, 0, 0, 'cyan')
    b.append(f'<g class="bob">{coin.svg(700, 64, s)}</g>')
    b.append(f'<g class="bob2">{q.svg(622, 74, s)}</g>')
    b.append(f'<g class="bob3">{gem.svg(ox + (11 - 8) * s, oy + 19 * s / 2 - 4 * s, s)}</g>')
    return svg_doc(w, h, "".join(b), "Patricio Torrez - Web & Mobile Developer")


# ------------------------------------------------------------------ section headers
def header(name, label, color):
    w, h = 960, 64
    icon = Scene(); icon.put(0, 0, 0, color); icon.put(1, 0, 0, color); icon.put(0, 0, 1, color)
    b = [f'<g class="float">{icon.svg(30, 26, 10)}</g>',
         text(label, 70, 20, 3, P['white'], shadow=P['dgrey']),
         f'<rect x="70" y="52" width="{width(label, 3)}" height="4" fill="{M[color][1]}"/>']
    return name, svg_doc(w, h, "".join(b), label)


# ------------------------------------------------------------------ character sheet
def character_sheet():
    w, h = 960, 320
    b = [frame(w, h, c2=P['blue'])]
    # portrait box
    b.append(f'<rect x="28" y="28" width="200" height="264" fill="{P["navy"]}"/>')
    b.append(stars(200, 120, 10).replace('x="', 'data-x="') if False else "")
    av = Scene()
    av.box(0, 0, 0, 5, 4, 1, 'grass')
    character(av, 1, 1, 1)
    b.append(f'<g class="float">{av.svg(122, 178, 14)}</g>')
    b.append(text("PLAYER 1", 64, 262, 3, P['yellow']))
    # identity column
    x0 = 256
    b.append(text("PATRICIO TORREZ", x0, 36, 4, P['white'], shadow=P['purple']))
    rows = [("CLASE / CLASS", "FULL-STACK DEV", P['cyan']),
            ("BASE / HOME", "MEXICO", P['white']),
            ("ESPECIAL / SPECIAL", "WEB + MOBILE", P['yellow']),
            ("MISION / QUEST", "LEVEL UP DAILY", P['lime'])]
    for i, (lab, val, col) in enumerate(rows):
        y = 86 + i * 56
        b.append(text(lab, x0, y, 2, P['lgrey']))
        b.append(text(val, x0, y + 20, 3, col))
    # stat bars
    bx = 580
    b.append(text("STATS", bx, 86, 3, P['yellow']))
    stats = [("FRONT-END", 8, P['cyan']), ("BACK-END", 8, P['lime']), ("MOBILE", 6, P['orange']),
             ("DATABASE", 7, P['sky']), ("PIXEL UI", 9, P['yellow'])]
    for i, (lab, v, col) in enumerate(stats):
        y = 122 + i * 34
        b.append(text(lab, bx, y + 4, 2, P['white']))
        for k in range(10):
            fill = col if k < v else P['dgrey']
            b.append(f'<rect x="{bx + 120 + k*22}" y="{y}" width="18" height="18" fill="{fill}"/>')
            if k < v:
                b.append(f'<rect x="{bx + 120 + k*22}" y="{y}" width="18" height="4" fill="{P["white"]}" opacity=".35"/>')
    b.append(f'<g class="blink">{text("@@@", w - 36 - width("@@@", 3), 36, 3, P["red"])}</g>')
    return svg_doc(w, h, "".join(b), "Character sheet: Patricio Torrez, full-stack dev")


# ------------------------------------------------------------------ level cards
def level_icon(kind):
    sc = Scene()
    if kind == 'calendar':
        sc.box(0, 0, 0, 5, 1, 5, 'white'); sc.box(0, 0, 4, 5, 1, 1, 'red')
        for x, z in [(1, 2), (3, 2), (1, 1), (2, 1)]:
            sc.put(x, 0, z, 'white', left=P['lgrey'])
        sc.put(3, 0, 1, 'white', left=P['red'])
        sc.put(1, 0, 5, 'dark'); sc.put(3, 0, 5, 'dark')
    elif kind == 'heart':
        rows = ["..##.##..", ".#######.", ".#######.", "..#####..", "...###...", "....#...."]
        rows = [".##.##.", "#######", "#######", ".#####.", "..###..", "...#..."]
        for zi, row in enumerate(rows):
            for xi, c in enumerate(row):
                if c == '#':
                    sc.put(xi, 0, len(rows) - zi, 'red')
        sc.put(1, 0, 5, 'red', left=P['white'])
    elif kind == 'ballot':
        sc.box(0, 0, 0, 4, 3, 3, 'blue')
        sc.box(1, 1, 3, 2, 1, 2, 'white')
        sc.put(1, 2, 1, 'blue', left=P['white']); sc.put(2, 2, 1, 'blue', left=P['white'])
        sc.put(2, 1, 6, 'yellow')
    elif kind == 'studio':
        cols = ['red', 'yellow', 'cyan', 'purple', 'blue', 'grass']
        k = 0
        for z, n in [(0, 3), (1, 2), (2, 1)]:
            for x in range(n):
                for y in range(n):
                    sc.put(x, y, z, cols[k % len(cols)]); k += 1
    return sc


def level_card(n, kind, lines, tech, accent):
    w, h = 440, 240
    b = [frame(w, h, c2=accent)]
    b.append(text(f"WORLD 1-{n}", 26, 26, 3, P['yellow']))
    b.append(text("x 03", w - 26 - width("x 03", 2), 30, 2, P['lgrey']))
    b.append(f'<rect x="22" y="56" width="166" height="160" fill="{P["navy"]}"/>')
    ic = level_icon(kind)
    xs = [k[0] for k in ic.v]; ys = [k[1] for k in ic.v]; zs = [k[2] for k in ic.v]
    s = 14
    cx = (max(xs) + min(xs) - max(ys) - min(ys)) / 2 * s
    cy = ((max(xs) + max(ys)) / 2 * s / 2) - (max(zs) / 2) * s
    b.append(f'<g class="float">{ic.svg(105 - cx, 136 - cy, s)}</g>')
    y = 70
    for ln in lines:
        b.append(text(ln, 206, y, 3, P['white'], shadow=P['dgrey'])); y += 30
    b.append(text(tech, 206, y + 6, 2, P['cyan']))
    b.append(f'<g class="blink">{text("} PLAY", w - 26 - width("} PLAY", 3), h - 50, 3, P["lime"])}</g>')
    return svg_doc(w, h, "".join(b), f"World 1-{n}: {' '.join(lines)}")


# ------------------------------------------------------------------ footer
def footer():
    w, h = 960, 140
    b = [frame(w, h)]
    b.append(stars(w, h, 25, avoid=lambda x, y: 140 < x < 820))
    t1 = "GRACIAS POR JUGAR / THANKS FOR PLAYING"
    b.append(text(t1, (w - width(t1, 3)) / 2, 36, 3, P['white'], shadow=P['purple']))
    t2 = "CONTINUE? } YES"
    b.append(f'<g class="blink">{text(t2, (w - width(t2, 3)) / 2, 80, 3, P["yellow"])}</g>')
    for i, (m, c) in enumerate([('yellow', 'bob'), ('red', 'bob2'), ('cyan', 'bob3')]):
        sc = Scene(); sc.put(0, 0, 0, m)
        b.append(f'<g class="{c}">{sc.svg(110 + i * 26, 70, 9)}</g>')
        b.append(f'<g class="{c}">{sc.svg(w - 162 + i * 26, 70, 9)}</g>')
    return svg_doc(w, h, "".join(b), "Thanks for playing")


# ------------------------------------------------------------------ avatar (square)
def avatar():
    w = h = 460
    b = [f'<rect width="{w}" height="{h}" fill="{P["bg"]}"/>', stars(w, h, 30)]
    sc = Scene()
    for x in range(5):
        for y in range(4):
            sc.put(x, y, 0, 'grass'); sc.put(x, y, -1, 'dirt')
    character(sc, 1, 1, 1)
    b.append(sc.svg(224, 262, 24))
    return svg_doc(w, h, "".join(b), "Patricio voxel avatar")


def write(name, data):
    with open(os.path.join(OUT, name), 'w') as f:
        f.write(data)
    print(f"{name:28s} {len(data)/1024:6.1f} KB")


write('banner.svg', banner())
write('character.svg', character_sheet())
for n, lab, col in [('header-character.svg', 'FICHA DE PERSONAJE / CHARACTER SHEET', 'blue'),
                    ('header-inventory.svg', 'INVENTARIO / INVENTORY', 'yellow'),
                    ('header-levels.svg', 'SELECCIONA NIVEL / LEVEL SELECT', 'red'),
                    ('header-stats.svg', 'ESTADÍSTICAS / STATS', 'cyan')]:
    write(*header(n, lab, col))
write('level-1.svg', level_card(1, 'calendar', ["RESERVACION"], "LARAVEL + TS", P['red']))
write('level-2.svg', level_card(2, 'heart', ["MENOS", "VIOLENCIA"], "FLUTTER + DART", P['purple']))
write('level-3.svg', level_card(3, 'ballot', ["LOS", "CHAVALINES"], "NODE + SOCKET.IO", P['blue']))
write('level-4.svg', level_card(4, 'studio', ["KALLIX", "STUDIO"], "ANGULAR + TS", P['teal']))
write('footer.svg', footer())
write('avatar.svg', avatar())
