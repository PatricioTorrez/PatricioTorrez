"""Tiny isometric voxel renderer -> flat-colored SVG paths (no gradients)."""

# Sweetie-16 inspired flat palette
P = dict(
    bg='#1a1c2c', purple='#5d275d', red='#b13e53', orange='#ef7d57', yellow='#ffcd75',
    lime='#a7f070', green='#38b764', teal='#257179', navy='#29366f', blue='#3b5dc9',
    sky='#41a6f6', cyan='#73eff7', white='#f4f4f4', lgrey='#94b0c2', grey='#566c86',
    dgrey='#333c57',
)

# (top, left(+y face), right(+x face))
M = dict(
    grass=('#a7f070', '#38b764', '#257179'),
    dirt=('#d4895a', '#a8603a', '#7a4128'),
    dirt2=('#a8603a', '#7a4128', '#5a2e1f'),
    stone=('#94b0c2', '#566c86', '#333c57'),
    light=('#f4f4f4', '#c4cfd8', '#94b0c2'),
    dark=('#566c86', '#333c57', '#262b44'),
    black=('#333c57', '#262b44', '#1a1c2c'),
    red=('#ef7d57', '#b13e53', '#7e2553'),
    yellow=('#ffe9a8', '#ffcd75', '#ef7d57'),
    blue=('#41a6f6', '#3b5dc9', '#29366f'),
    cyan=('#a8f6fa', '#73eff7', '#41a6f6'),
    purple=('#a9508f', '#7e2553', '#5d275d'),
    skin=('#ffd8b0', '#f0b48a', '#cc8a62'),
    hair=('#7a4a32', '#55311f', '#3d2216'),
    wood=('#c8915e', '#96603a', '#6b4128'),
    leaf=('#38b764', '#257179', '#1d5157'),
    white=('#f4f4f4', '#d2dbe2', '#94b0c2'),
    pants=('#566c86', '#333c57', '#29366f'),
    screen=('#29366f', '#29366f', '#29366f'),
)


class Scene:
    def __init__(self):
        self.v = {}

    def put(self, x, y, z, mat, left=None, right=None, top=None, blink=None):
        t, l, r = M[mat] if isinstance(mat, str) else mat
        self.v[(x, y, z)] = dict(c=(top or t, left or l, right or r), blink=blink)

    def box(self, x, y, z, dx, dy, dz, mat):
        for i in range(dx):
            for j in range(dy):
                for k in range(dz):
                    self.put(x + i, y + j, z + k, mat)

    def remove(self, x, y, z):
        self.v.pop((x, y, z), None)

    def svg(self, ox, oy, s, cls_faces=None):
        h = s / 2
        polys = []  # (color, d, cls)
        for (x, y, z) in sorted(self.v, key=lambda p: (p[0] + p[1] + p[2], p[2], p[0])):
            vo = self.v[(x, y, z)]
            top, left, right = vo['c']
            X = ox + (x - y) * s
            Y = oy + (x + y) * h - z * s
            f = lambda pts: "M" + "L".join(f"{a:g} {b:g}" for a, b in pts) + "z"
            if (x, y + 1, z) not in self.v:
                d = f([(X - s, Y), (X, Y + h), (X, Y + h + s), (X - s, Y + s)])
                polys.append((left, d, None))
                if vo['blink']:
                    polys.append((vo['blink'], d, 'blink'))
            if (x + 1, y, z) not in self.v:
                polys.append((right, f([(X, Y + h), (X + s, Y), (X + s, Y + s), (X, Y + h + s)]), None))
            if (x, y, z + 1) not in self.v:
                polys.append((top, f([(X, Y - h), (X + s, Y), (X, Y + h), (X - s, Y)]), None))
        # merge consecutive same-color, class-less faces
        out, cur_c, cur_d = [], None, []
        def flush():
            if cur_d:
                out.append(f'<path fill="{cur_c}" d="{"".join(cur_d)}"/>')
        for c, d, cls in polys:
            if cls:
                flush(); cur_d = []; cur_c = None
                out.append(f'<path class="{cls}" fill="{c}" d="{d}"/>')
            elif c == cur_c:
                cur_d.append(d)
            else:
                flush(); cur_c, cur_d = c, [d]
        flush()
        return "".join(out)


def character(sc, x, y, z):
    """3 wide (x), 2 deep (y), ~10 tall 8-bit dev. Face looks toward +y."""
    sc.box(x, y, z, 1, 2, 2, 'pants'); sc.box(x + 2, y, z, 1, 2, 2, 'pants')   # legs
    sc.box(x, y, z + 2, 3, 2, 3, 'blue')                                         # shirt
    sc.put(x + 1, y + 1, z + 4, 'blue', left=M['white'][0])                     # collar
    sc.box(x - 1, y + 1, z + 3, 1, 1, 2, 'blue'); sc.put(x - 1, y + 1, z + 2, 'skin')  # arms
    sc.box(x + 3, y + 1, z + 3, 1, 1, 2, 'blue'); sc.put(x + 3, y + 1, z + 2, 'skin')
    sc.box(x, y, z + 5, 3, 2, 3, 'skin')                                         # head
    sc.box(x, y, z + 8, 3, 2, 1, 'hair')                                         # hair top
    sc.box(x, y, z + 6, 3, 1, 2, 'hair')                                         # hair back
    sc.put(x, y + 1, z + 6, 'skin', left='#1a1c2c')                              # eyes
    sc.put(x + 2, y + 1, z + 6, 'skin', left='#1a1c2c')
