# Guía para dejar tu perfil de GitHub listo 🕹️

## 1. Crear el repo especial del README (5 min)

1. Entra a https://github.com/new
2. **Repository name:** `PatricioTorrez` (exactamente tu usuario). GitHub te dirá *"✨ You found a secret!"*.
3. Márcalo como **Public** y créalo (sin README, lo subimos nosotros).
4. Sube el contenido de la carpeta `profile/` del zip: `README.md`, la carpeta `assets/` y la carpeta `.github/` (en la web: *Add file → Upload files*, arrastra todo; la carpeta `.github` a veces está oculta en tu explorador, actívala para verla).
5. Ve a **Settings → Actions → General → Workflow permissions** y elige **Read and write permissions**.
6. Ve a **Actions → Generate snake → Run workflow**. En ~1 minuto aparece la serpiente que se come tus contribuciones (crea la rama `output`).

## 2. Campos del perfil (github.com/settings/profile)

| Campo | Qué poner |
|---|---|
| **Name** | `Patricio Torrez` |
| **Bio** (máx. 160) | Elige una 👇 |
| **Pronouns** | Opcional |
| **URL** | `https://www.linkedin.com/in/patricio-torrez-de-paz-45b309227` (o tu portafolio cuando lo tengas) |
| **Social accounts** | LinkedIn (y cualquier otra red que quieras mostrar) |
| **Company** | Vacío (decidiste no mencionarlo) |
| **Location** | `México 🇲🇽` |
| **Profile picture** | Sube `avatar.png` (avatar voxel a juego con el banner) |

**Opciones de bio:**
- `🕹️ Web & mobile dev · Node, Angular, Laravel & Flutter · Pixel art lover 👾`
- `👾 Desarrollador web y móvil · Construyo apps del primer pixel al deploy`
- `🎮 Player 1 · Web & Mobile Dev · Always leveling up`

## 3. Repos fijados (Pinned) y su "About"

En tu perfil: **Customize your pins** → fija los 4 repos en este orden. Luego en cada repo, el engrane ⚙️ junto a *About*:

| Repo | Description | Topics | Website |
|---|---|---|---|
| reservacion | Sistema de reservaciones con Laravel y TypeScript · Booking system | `laravel` `php` `typescript` `vite` | — |
| app_menos_violencia | App móvil en Flutter para la prevención de la violencia | `flutter` `dart` `android` `mobile-app` | — |
| votos-chavalines | Votaciones en tiempo real para torneos entre amigos ⭐ | `nodejs` `express` `socket-io` `realtime` | — |
| Kallix-Studio | Web app en Angular desplegada en Vercel | `angular` `typescript` `vercel` | `https://kallix-studio.vercel.app` |

También conviene reemplazar los README genéricos (Laravel / Flutter / Angular por defecto) con uno corto que diga qué hace cada proyecto: suben mucho la impresión que da tu perfil.

## 4. Revisa estos supuestos

- **app_menos_violencia:** su README no explica el propósito; inferí "prevención de la violencia" por el nombre. Corrige la descripción si no es así.
- **MySQL** en el inventario: lo agregué porque Laravel lo usa por defecto; quítalo si no lo usas.
- **Barras de STATS** (front-end 8, back-end 8, mobile 6, database 7, pixel UI 9) y **"BASE: MEXICO"** en la ficha: valores inventados, se cambian en `gen/build.py`.

## 5. Editar los gráficos

Todo el arte está generado por código (`gen/`): `python3 gen/build.py` vuelve a crear los SVG en `profile/assets/`. Para cambiar textos, stats o la escena voxel, edita `build.py` (fuente de pixeles en `pixfont.py`, motor voxel en `voxel.py`).

**Nota:** las tarjetas de stats usan instancias públicas gratuitas (github-readme-stats, streak-stats). A veces tardan o fallan por límite de uso; si pasa seguido, se pueden autoalojar gratis en Vercel.
